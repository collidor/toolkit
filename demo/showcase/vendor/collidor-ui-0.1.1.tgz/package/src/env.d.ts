/// <reference types="vite-plus/client" />

declare module '*.css' {
  const content: string
  export default content
}

declare module '*?inline' {
  const content: string
  export default content
}
